CREATE DATABASE mess;
USE mess;

CREATE USER 'mess'@'%' BY "MESS4ever!";
GRANT ALL PRIVILEGES ON `mess`.* TO 'mess'@'%';

CREATE TABLE `shortcut_url` (
  `shortcut` varchar(20) NOT NULL,
  `url` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`shortcut`));

INSERT INTO `shortcut_url` VALUES 
  ('db','http://www.mysql.com'),
  ('nice','https://www.google.de/maps/place/Restaurant+Nautilus/@39.8009036,2.693936,17z/data=!4m13!1m7!3m6!1s0x1297b8766606c129:0xb7eb9bff02d2ecc0!2sMallorca!3b1!8m2!3d39.6952629!4d3.0175712!3m4!1s0x0:0x1226c6854bc936f0!8m2!3d39.8009862!4d2.6940027'),
  ('report','localhost:8888/report.mess'),
  ('se','http://google.de'),
  ('siemens','http://www.siemens.de');


