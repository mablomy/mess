var http = require("http"),
    url  = require("url"),
    formidable = require("formidable"),
    querystring = require("querystring"),
    json2html = require("node-json2html"),
    path = require("path"),
    fs   = require("fs"),
    mysql= require("mysql"),
    PORT = process.env.PORT || 8888; // Variable name must be PORT in ACCS


var connection = mysql.createConnection({
  host     : url.parse("mysql://"+process.env.MYSQLCS_CONNECT_STRING).hostname || 'localhost',
  port     : process.env.MYSQLCS_MYSQL_PORT || '4000',
  user     : process.env.MYSQLCS_USER_NAME || 'mess',
  password : process.env.MYSQLCS_USER_PASSWORD ||'MESS4ever!',
  database : url.parse("mysql://"+process.env.MYSQLCS_CONNECT_STRING).pathname.substr(1) || 'mess',
  multipleStatements : true
});
console.log ("Environment variable is: ");
console.log (process.env.MYSQLCS_CONNECT_STRING);
console.log ("URL object is: ");
console.log (url.parse(process.env.MYSQLCS_CONNECT_STRING));
console.log ("hostname is: ");
console.log (url.parse(process.env.MYSQLCS_CONNECT_STRING).hostname);
console.log ("connection object is: ");
console.log (connection);
console.log ("Dumping all environment variables:");
console.log (process.env);


function errorpage (request, response, err) {
    response.writeHead(500);
    response.write("<html><head><title>MESS - Error</title></head><body><h1>What a MESS</h1><br>");
    response.write("This is embarrassing. My Excellent Shortcut Service has an error.<br>");
    response.write("Please send a meaningless bug report to /dev/null.<br>");
    response.write("<br>"+JSON.stringify(err)+"</body></html>");
    response.end();
}



function startpage(response) {

    var filename = path.join(process.cwd(),"startpage.mess");
    fs.readFile(filename, "binary", function(err,file) {
    response.writeHead(200);
    response.write(file, "binary");
    response.end();
    });
}


function register(request, response) {
    var form = new formidable.IncomingForm();
    form.parse(request, function(err, fields, files) {
      if (err) errorpage(request, response, err);
      else {
	var insert="INSERT INTO shortcut_url (url,shortcut) VALUES('"+fields.url+"','"+fields.shortcut+"')";
        connection.query(insert, function(err, rows, fields) {
        if (err) errorpage(request, response, err);
        else {
            response.writeHead(200);
            response.write("Data written: "+insert, "binary");
            response.end();
        }});
      }
    });
}


function report(request, response) {
    var query_shortcut=querystring.parse(url.parse(request.url).query).shortcut;
    var stmts = "SELECT COUNT(*) AS counter FROM shortcut_url;"+
                "SELECT shortcut, url FROM shortcut_url WHERE shortcut='"+query_shortcut+"'";

    connection.query(stmts, function(err, rows, fields) {
      if (err)
        errorpage(request, response, err);
      else {
	var rowcount = rows[0][0].counter;
console.log(stmts);
        var transform = { "<>":"tr","html":[
                         {"<>":"td","html":"${shortcut}"},
                         {"<>":"td","html":"${url}"}
                        ]};

        // output of reports page
        response.writeHead(200);
        response.write("<html><header><title>MESS Reports</title></header><body>");
        response.write("<h1>MESS - The full report</h1>");
        response.write("Number of stored shortcuts: " + rowcount +"<br>");
        response.write("<form action='/report.mess' method='get'><fieldset><legend>Query a shortcut</legend>");
        response.write("Shortcut:<input type='text' name='shortcut' value=''><input type='submit' value='Query'>");
        response.write("</fieldset></form><br>");
        response.write("<table><tbody><tr><th>Shortcut</th><th>URL</th></tr>"+json2html.transform(JSON.stringify(rows[1]), transform)+"</tbody></table></body>", "binary");
        response.end();
      }
    });
}


function forward(request, response, key) {
    const forward1='<html> <head> <meta http-equiv="refresh" content="0; URL=';
    const forward2='"> </head> <body> <h1>MESS</h1> <p>This forward is presented to you by MESS - My Excellent Shortcut Server </p> </body> </html>';
    var query = 'SELECT url FROM shortcut_url WHERE shortcut="'+key+'"';
    connection.query(query, function(err, rows, fields) {
      if (err) errorpage(request, response, err);
      else if (rows.length == 0) startpage(response);
      else {
        response.writeHead(200);
        response.write(forward1.concat(rows[0].url).concat(forward2), "binary");
        response.end();
      }
    });      
}


function server(request, response) {
    var key = url.parse(request.url).pathname.substr(1);
    if(key == "")
        startpage(response);
    else if(key == "register.mess")
	register(request, response);
    else if (key=="report.mess")
        report(request, response);
    else
        forward(request, response, key);
}


http.createServer(server).listen(parseInt(PORT, 10));
console.log("MESS server running at\n  => http://localhost:" + PORT + "/\nCTRL + C to shutdown");
connection.connect(function(err){if(err) console.log("Error connecting database\n"+err);});


